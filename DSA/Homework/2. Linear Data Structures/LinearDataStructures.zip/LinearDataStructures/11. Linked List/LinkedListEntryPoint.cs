﻿namespace LinearDataStructures
{
    class LinkedListEntryPoint
    {
        static void Main(string[] args)
        {

        }
    }
}
