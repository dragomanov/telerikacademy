(function() {
    console.log(document.querySelector("input[type=text]").value);
})();
