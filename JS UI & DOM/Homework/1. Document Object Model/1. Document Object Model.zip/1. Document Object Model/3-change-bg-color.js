document.querySelector("#btn").onclick = function () {
    document.body.style.backgroundColor = document.querySelector("input[type=color]").value;
};
