﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResidentialManager
{
    public class SupervisoryCommittee : InhabitantList
    {
        public SupervisoryCommittee()
            : base()
        {
        }
    }
}
