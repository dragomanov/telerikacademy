﻿public enum MaterialTypes
{
    panel,
    brick,
}