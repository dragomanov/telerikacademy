﻿public enum InhabitantType
{
    Owner,
    Tenant
}