﻿using System;

class PrintTenYearsOlder
{
    static void Main()
    {
        int years = int.Parse(Console.ReadLine());
        Console.WriteLine(years + 10);
    }
}
