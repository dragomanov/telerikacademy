﻿using System;

class PrintSquare
{
    static void Main()
    {
        Console.WriteLine(Math.Pow(12345, 2));
    }
}
