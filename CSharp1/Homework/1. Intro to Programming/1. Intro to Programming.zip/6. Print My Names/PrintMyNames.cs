﻿using System;

class PrintMyNames
{
    static void Main()
    {
        Console.WriteLine("Antoni Dragomanov");
    }
}
