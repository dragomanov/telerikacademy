﻿using System;

class PrintCurrentDateTime
{
    static void Main()
    {
        DateTime Now = DateTime.Now;
        Console.WriteLine(Now);
    }
}
