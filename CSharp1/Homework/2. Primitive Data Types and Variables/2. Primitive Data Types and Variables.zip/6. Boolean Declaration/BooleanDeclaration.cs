﻿using System;

    class BooleanDeclaration
    {
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine(isFemale);
        }
    }
