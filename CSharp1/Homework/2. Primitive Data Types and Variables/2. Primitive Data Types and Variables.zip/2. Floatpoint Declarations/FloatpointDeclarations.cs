﻿using System;

class FloatpointDeclarations
{
    static void Main()
    {
        double d1 = 34.567839023;
        float f1 = 12.345f;
        double d2 = 8923.1234857;
        float f2 = 3456.091f;

        Console.WriteLine("{0}\n{1}\n{2}\n{3}", d1, f1, d2, f2);
    }
}