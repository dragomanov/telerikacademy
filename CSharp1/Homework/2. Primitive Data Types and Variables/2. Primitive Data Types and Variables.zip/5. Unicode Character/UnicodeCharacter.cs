﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char unicodeChar = '\u0048';
        Console.WriteLine(unicodeChar);
    }
}

