﻿using System;

class HexadecimalInteger
{
    static void Main()
    {
        int hex = 0xFE;
        Console.WriteLine(hex);
    }
}
