﻿using System;

class IntegerDeclarations
{
    static void Main()
    {
        ushort @ushort = 52130;
        sbyte @sbyte = -115;
        int @int = 4825932;
        byte @byte = 97;
        short @short = -10000;

        Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}", @ushort, @sbyte, @int, @byte, @short);
    }
}
