﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Background
{
    // TODO: Make stars in the distance 
    // fade (DarkGray and maybe Grey)
    // small, possibly single characters like . * ` ¤  ° · • ☼
    // all over the play area 
    // moving to the left
}
