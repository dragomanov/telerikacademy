namespace GetAllFeedsAndMakeHtml
{
    public class Rss
    {
        public Channel Channel { get; set; }
    }
}