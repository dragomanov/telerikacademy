namespace GetAllFeedsAndMakeHtml
{
    public class RssFeed
    {
        public Rss Rss { get; set; }
    }
}